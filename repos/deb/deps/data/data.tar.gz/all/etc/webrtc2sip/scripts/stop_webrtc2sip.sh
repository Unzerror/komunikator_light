#!/bin/bash

sda_i=0

while true
do

    if [ $sda_i -gt 9 ]
    then
        echo "stop error"
        break
    fi


    if ps axu | grep -i "screen -dms webrtc2sip webrtc2sip" | grep -vq grep
    then
        sudo screen -S webrtc2sip -X quit


        sleep 3s
    else
        echo "process is stopped"
        break
    fi


    let "sda_i++"

done