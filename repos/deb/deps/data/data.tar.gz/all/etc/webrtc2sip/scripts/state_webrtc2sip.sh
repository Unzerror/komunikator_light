#!/bin/bash

if ps axu | grep -i "screen -dms webrtc2sip webrtc2sip" | grep -vq grep
then
    echo "process is running"
else
    echo "process is stopped"
fi